# Phing plugin

This plugin adds autocompletion for [`phing`](https://github.com/phingofficial/phing) targets.

To use it, add `phing` to the plugins array of your `.zshrc` file:

```zsh
plugins=(... phing)
```
