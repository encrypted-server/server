# hitokoto plugin

Displays a random quote taken from [hitokoto.cn](https://v1.hitokoto.cn/)

Created by [Sinrimin](https://github.com/sinrimin)

## Usage

Add the plugin to the plugins array in your zshrc file and restart zsh:

```zsh
plugins=(... hitokoto)
```

Then, run `hitokoto` to get a new random quote.
